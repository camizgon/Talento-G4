# Revisión del desafío 'Javascript en práctica'

Existen pequeñas modificaciones en ejercicio1.html y ejercicio2.html para poder
completar el desafío:

  * se agregan clases .error y .success en [ejercicio1](./ejercicio1.html#L13) y
  * Se agrega el id#botonera en [ejercicio2](./ejercicio2.html#L17) 

